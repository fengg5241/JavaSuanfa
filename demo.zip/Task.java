package com.example.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

class Task implements Callable<String> {
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String str;
    public Task(String str){
        this.str = str;
    }
    @Override
      public String call() throws Exception {
//    	System.out.println(new Date());
        System.out.println("Send request to GNS..." + str + "[" + sdf.format(new Date()) + "]" );
        TimeUnit.SECONDS.sleep(3);
        return str;
    }
}