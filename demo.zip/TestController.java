package com.example.demo;


import com.google.common.util.concurrent.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@RestController
public class TestController {
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @Autowired
    private AccessLimitService accessLimitService;

    @RequestMapping("/hello")
    @ResponseBody
    public String hello() {
//        System.out.println("aceess wait [" + sdf.format(new Date()) + "] -------");
//        accessLimitService.acquire();
        long id = Thread.currentThread().getId();
        System.out.println("aceess start [" + sdf.format(new Date()) + "] -------"+id);

//        try {
//                Thread.sleep(5000);
//            }catch (InterruptedException e){
//                e.printStackTrace();
//            }
//        System.out.println("aceess end [" + sdf.format(new Date()) + "] -------");
//        System.out.println("aceess finish [" + sdf.format(new Date()) + "] -------");
        testRateLimiter(id);
//        if(accessLimitService.tryAcquire()){
//            //模拟业务执行500毫秒
//            try {
//                Thread.sleep(5000);
//            }catch (InterruptedException e){
//                e.printStackTrace();
//            }
//            System.out.println("aceess success [" + sdf.format(new Date()) + "] -------");
//            return "aceess success [" + sdf.format(new Date()) + "]-------";
//        }else{
//            System.out.println("aceess limit [" + sdf.format(new Date()) + "]-------");
//            return "aceess limit [" + sdf.format(new Date()) + "]-------";
//        }

//        return "Hello Spring Boot";
        return "";
    }

    public  void testRateLimiter(long id) {
        int numberOfPubRequest = 10;
        List<String> subDetailResponse = new ArrayList<String>();
        CountDownLatch countDownLatch = new CountDownLatch(numberOfPubRequest);
        ListeningExecutorService executorService = MoreExecutors
                .listeningDecorator(Executors.newCachedThreadPool());
//        RateLimiter limiter = RateLimiter.create(0.2);
        for (int i = 0; i < numberOfPubRequest; i++) {
            //Will block if more then 1 request in 2 seconds
            accessLimitService.acquire();
            final ListenableFuture<String> listenableFuture = executorService
                    .submit(new Task("is "+ i + "======="+id));

            Futures.addCallback(listenableFuture, new FutureCallback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            subDetailResponse.add(result);
//                            System.out
//                                    .println("get  result with callback "
//                                            + result);
                            countDownLatch.countDown();
                        }
                        @Override
                        public void onFailure(Throwable t) {
                            t.printStackTrace();
                        }
                    }
            );

        }

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("===========All GNS responses are returned========");
        System.out.println("aceess finish [" + sdf.format(new Date()) + "] -------");
        for (String str : subDetailResponse) {
            System.out.println(str);
        }

    }
}
