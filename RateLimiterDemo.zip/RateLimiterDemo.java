import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.RateLimiter;

public class RateLimiterDemo {

	public static void main(String[] args) {
		testRateLimiter();
//        testListenableFuture();

	}
	
	public static void testRateLimiter() {
		int numberOfPubRequest = 10;
		List<String> subDetailResponse = new ArrayList<String>();
		CountDownLatch countDownLatch = new CountDownLatch(numberOfPubRequest);
        ListeningExecutorService executorService = MoreExecutors
                .listeningDecorator(Executors.newCachedThreadPool());
        RateLimiter limiter = RateLimiter.create(2);
        for (int i = 0; i < numberOfPubRequest; i++) {
        	//Will block if more then 1 request in 2 seconds
        	limiter.acquire();
            final ListenableFuture<String> listenableFuture = executorService
                      .submit(new Task("is "+ i));
//            try {
//				System.out.println(listenableFuture.get());
//			} catch (InterruptedException | ExecutionException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
            
            Futures.addCallback(listenableFuture, new FutureCallback<String>() {
                @Override
                      public void onSuccess(String result) {
                	subDetailResponse.add(result);
                    System.out
                                .println("get  result with callback "
                                    + result);
                    countDownLatch.countDown();
                }
                @Override
                      public void onFailure(Throwable t) {
                    t.printStackTrace();
                }
            }
            );
            
        }
        
        try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("===========All GNS responses are returned========");
        for (String str : subDetailResponse) { 		      
            System.out.println(str); 		
       }
        
    }
    public static void testListenableFuture() {
        ListeningExecutorService executorService = MoreExecutors
                .listeningDecorator(Executors.newCachedThreadPool());
        final ListenableFuture<String> listenableFuture = executorService
                .submit(new Task("testListenableFuture"));
        try {
            System.out.println(listenableFuture.get());
        }
        catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        catch (ExecutionException e1) {
            e1.printStackTrace();
        }
        // Option 1
        listenableFuture.addListener(new Runnable() {
            @Override
                  public void run() {
                try {
                    System.out.println("get listenable future's result "
                                  + listenableFuture.get());
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }
        , executorService);
        //Option 2
        Futures.addCallback(listenableFuture, new FutureCallback<String>() {
            @Override
                  public void onSuccess(String result) {
                System.out
                            .println("get listenable future's result with callback "
                                + result);
            }
            @Override
                  public void onFailure(Throwable t) {
                t.printStackTrace();
            }
        }
        );
    }

}
