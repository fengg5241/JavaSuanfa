import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

class Task implements Callable<String> {
    String str;
    public Task(String str){
        this.str = str;
    }
    @Override
      public String call() throws Exception {
    	System.out.println(new Date());
        System.out.println("Send request to GNS..." + str);
        TimeUnit.SECONDS.sleep(3);
        return str;
    }
}